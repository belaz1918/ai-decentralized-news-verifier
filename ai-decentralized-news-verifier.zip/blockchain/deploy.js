const hre = require("hardhat");

async function main() {
  const NewsVerification = await hre.ethers.getContractFactory("NewsVerification");
  const newsVerification = await NewsVerification.deploy();
  await newsVerification.deployed();
  console.log("Contract deployed to:", newsVerification.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
